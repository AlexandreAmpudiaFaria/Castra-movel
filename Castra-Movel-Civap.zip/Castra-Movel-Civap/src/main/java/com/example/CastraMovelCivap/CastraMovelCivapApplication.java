package com.example.CastraMovelCivap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CastraMovelCivapApplication {

	public static void main(String[] args) {
		SpringApplication.run(CastraMovelCivapApplication.class, args);
	}

}
